<h1 align="center">Gaming-x Android Performance Optimizer</h1>

<div align="center">
    <img src="https://img.shields.io/badge/Updated-2023/11/17-blue.svg?longCache=true&style=popout-round"/>
    <img src="https://img.shields.io/badge/Magisk-Module-green.svg?longCache=true&style=flat-round"/>
    <h3>
        This is <a href="https://github.com/topjohnwu/Magisk">Magisk</a> module to disabling smartphone thermal engine. 
    </h3>
</div>

## Description

This is a Magisk module that is useful for disabling the thermal of your smartphone.
Use it wisely, and all risks are your own responsibility.

## Requirement

- Magisk v23.0 or higher

## Changelog

- Check out what's new [here](https://github.com/mahisataruna/)

## Note

Please use this module wisely. I am not responsible for any damage caused by this module. All risks are your own.
