<h1 align="center">Changelog</h1>

### Version 1.0

- Universal Initial Build Version 1.0
